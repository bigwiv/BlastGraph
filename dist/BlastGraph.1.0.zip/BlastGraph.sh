java -Xms64M -Xmx1024M -jar BlastGraph.1.0.jar
